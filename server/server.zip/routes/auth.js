// routes/auth.js
const express = require('express');
const router = express.Router();
const { register, login ,forgotPassword, resetPasswordWithOtp, verifyEmail } = require('../controllers/auth.controller.js');

router.post('/register', register);
router.post('/login', login);
router.post('/forgot-password', forgotPassword);
router.post('/reset-password-otp', resetPasswordWithOtp);
router.get('/verify-email/:token', verifyEmail);

module.exports = router;