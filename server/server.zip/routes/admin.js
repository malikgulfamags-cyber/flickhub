const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const { getFeatured, addFeatured, removeFeatured, isAdmin } = require('../controllers/admin.controller');

// All admin routes require authentication and admin role
router.use(auth);
router.use(isAdmin);

// Featured movies management
router.get('/featured', getFeatured);
router.post('/featured', addFeatured);
router.delete('/featured', removeFeatured);

module.exports = router;