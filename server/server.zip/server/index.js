const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
require('dotenv').config();


const app = express();

app.use(cors());
app.use(express.json());

mongoose.connect(process.env.MONGO_URI)
  .then(() => console.log('MongoDB connected'))
  .catch(err => console.log(err));

  app.use(express.json()) //allow json data 
  // Routes
const authRoutes = require('../routes/auth.js');
const userRoutes = require('../routes/user.js');
const movieRoutes = require('../routes/movies.js');
const reviewsRoutes = require('../routes/reviews.js');
const adminRoutes = require('../routes/admin.js');
app.use('/api/auth', authRoutes);
app.use('/api/user', userRoutes);
app.use('/api/movies', movieRoutes);
app.use('/api/movies', reviewsRoutes);
app.use('/api/admin', adminRoutes);

app.get('/', (req, res) => {
  res.send('FlickHub backend running!');
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});