// controllers/auth.controller.js
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const crypto = require('crypto');
const sendEmail = require('../helpers/sendEmail');
const generateOtp = require('../helpers/generateOtp');
const generateVerificationToken = require('../helpers/generateToken');


const register = async (req, res) => {
  try {
    const { name, email, password } = req.body;

    // Validation
    if (!name || !email || !password) {
      return res.status(400).json({ msg: 'All fields are required' });
    }

    // Check if user already exists
    let user = await User.findOne({ email });
    if (user) {
      return res.status(400).json({ msg: `This email "${email}" is already registered!` });
    }

    // Create new user
    user = new User({ name, email, password, isVerified: false });

    // Hash password
    const salt = await bcrypt.genSalt(10);
    user.password = await bcrypt.hash(password, salt);

    // Generate unique username from email
    let baseUsername = email.split('@')[0];
    let username = baseUsername;
    let count = 1;

    while (await User.findOne({ username })) {
      username = `${baseUsername}${count}`;
      count++;
    }
    user.username = username;

    const verificationToken = generateVerificationToken();
    user.verificationToken = verificationToken;
    user.verificationTokenExpire = Date.now() + 24 * 60 * 60 * 1000; // 24 hours

    // Save user
    await user.save();

    // Generate JWT token
  // Build verification URL (adjust frontend URL)
    const verifyUrl = `${process.env.CLIENT_URL || 'http://localhost:5173'}/verify-email/${verificationToken}`;

    const htmlContent = `
      <html>
        <body style="font-family: Arial, sans-serif;">
          <div style="max-width: 500px; margin: 0 auto; padding: 20px; border: 1px solid #ddd;">
            <h2 style="color: #e50914;">Welcome to Flick Hub!</h2>
            <p>Hello ${name},</p>
            <p>Please verify your email address by clicking the link below:</p>
            <a href="${verifyUrl}" style="display: inline-block; background-color: #e50914; color: #fff; padding: 10px 20px; text-decoration: none;">Verify Email</a>
            <p>This link expires in 24 hours.</p>
            <p>If you didn't create an account, ignore this email.</p>
            <p>Regards,<br/>Flick Hub Team</p>
          </div>
        </body>
      </html>
    `;

    await sendEmail(email, 'Verify your email address', htmlContent);

    res.status(201).json({ msg: 'Registration successful! Please verify your email to log in.' });

  } catch (err) {
    console.error(err);
    res.status(500).json({ msg: 'Server error' });
  }
};

const verifyEmail = async (req, res) => {
  try {
    const { token } = req.params;

    const user = await User.findOne({
      verificationToken: token,
      verificationTokenExpire: { $gt: Date.now() }
    });

    if (!user) {
      return res.status(400).json({ msg: 'Invalid or expired verification token' });
    }

    user.isVerified = true;
    user.verificationToken = undefined;
    user.verificationTokenExpire = undefined;
    await user.save();

    res.json({ msg: 'Email verified successfully. You can now log in.' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ msg: 'Server error' });
  }
};

const login = async (req, res) => {
  try {
    const { email, password } = req.body;

    // Find user
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(400).json({ msg: `This email ${email} is not registered!` });
    }

    // Check if email is verified
    if (!user.isVerified) {
      return res.status(401).json({ msg: 'Please verify your email before logging in. Check your inbox for the verification link.' });
    }

    // Check password
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(400).json({ msg: 'Wrong Password!' });
    }

    // Generate token
    const payload = { id: user._id };
    const token = jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: '7d' });

    // Send response
    res.json({
      token,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        username: user.username,
        role: user.role
      }
    });

  } catch (err) {
    console.error(err);
    res.status(500).json({ msg: 'Server error' });
  }
};


// POST /api/auth/forgot-password
const forgotPassword = async (req, res) => {
  const { email } = req.body;
  if (!email) return res.status(400).json({ msg: 'Email is required' });

  try {
    const user = await User.findOne({ email });
    if (!user) return res.status(404).json({ msg: 'User not found' });

    const otp = generateOtp();
    user.resetOtp = otp;
    user.resetOtpExpire = Date.now() + 10 * 60 * 1000; // 10 minutes
    await user.save();

    // Send OTP via email
    const htmlContent = `
      <html>
        <body>
          <div style="max-width: 500px; background: #fff; padding: 20px;">
            <h2 style="color: #e50914;">Reset your password</h2>
            <p>Your OTP is: <strong>${otp}</strong></p>
            <p>This code expires in 10 minutes.</p>
            <p>If you didn't request this, ignore this email.</p>
          </div>
        </body>
      </html>
    `;
    await sendEmail(email, 'Password Reset OTP', htmlContent);
    res.json({ msg: 'OTP sent to your email' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ msg: 'Server error' });
  }
};

// POST /api/auth/reset-password-otp
 const resetPasswordWithOtp = async (req, res) => {
  const { email, otp, newPassword } = req.body;
  if (!email || !otp || !newPassword) {
    return res.status(400).json({ msg: 'All fields are required' });
  }

  try {
    const user = await User.findOne({
      email,
      resetOtp: otp,
      resetOtpExpire: { $gt: Date.now() },
    });
    if (!user) return res.status(400).json({ msg: 'Invalid or expired OTP' });

    // Hash new password
    const salt = await bcrypt.genSalt(10);
    user.password = await bcrypt.hash(newPassword, salt);
    user.resetOtp = undefined;
    user.resetOtpExpire = undefined;
    await user.save();

    res.json({ msg: 'Password reset successful' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ msg: 'Server error' });
  }
};

// Update module.exports
module.exports = {
  register,
  verifyEmail,
  login,
  forgotPassword,
  resetPasswordWithOtp,
};