const Featured = require('../models/Featured');
const User = require('../models/User');

// Get featured movies (list of TMDB IDs)
const getFeatured = async (req, res) => {
  try {
    let featured = await Featured.findOne();
    if (!featured) {
      featured = new Featured({ movieIds: [] });
      await featured.save();
    }
    res.json(featured.movieIds);
  } catch (err) {
    console.error(err);
    res.status(500).json({ msg: 'Server error' });
  }
};

// Add a featured movie (TMDB ID)
const addFeatured = async (req, res) => {
  try {
    const { movieId } = req.body;
    if (!movieId) return res.status(400).json({ msg: 'Movie ID is required' });

    let featured = await Featured.findOne();
    if (!featured) {
      featured = new Featured({ movieIds: [] });
    }

    // Avoid duplicates
    if (!featured.movieIds.includes(movieId)) {
      featured.movieIds.push(movieId);
      featured.updatedAt = Date.now();
      await featured.save();
    }
    res.json(featured.movieIds);
  } catch (err) {
    console.error(err);
    res.status(500).json({ msg: 'Server error' });
  }
};

// Remove a featured movie
const removeFeatured = async (req, res) => {
  try {
    const { movieId } = req.body;
    if (!movieId) return res.status(400).json({ msg: 'Movie ID is required' });

    let featured = await Featured.findOne();
    if (featured) {
      featured.movieIds = featured.movieIds.filter(id => id !== movieId);
      featured.updatedAt = Date.now();
      await featured.save();
    }
    res.json(featured ? featured.movieIds : []);
  } catch (err) {
    console.error(err);
    res.status(500).json({ msg: 'Server error' });
  }
};

// Optional: Check if a user is admin (middleware)
const isAdmin = async (req, res, next) => {
  try {
    const user = await User.findById(req.user.id);
    if (!user || user.role !== 'admin') {
      return res.status(403).json({ msg: 'Access denied' });
    }
    next();
  } catch (err) {
    res.status(500).json({ msg: 'Server error' });
  }
};

module.exports = {
  getFeatured,
  addFeatured,
  removeFeatured,
  isAdmin
};